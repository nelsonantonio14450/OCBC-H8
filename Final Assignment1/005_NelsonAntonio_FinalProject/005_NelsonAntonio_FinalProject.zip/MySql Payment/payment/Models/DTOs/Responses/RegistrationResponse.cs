using PaymentWithJWT.Configuration;


namespace PaymentWithJWT.Models.DTO.Responses
{
    public class RegistrationResponse : AuthResult { }
}
